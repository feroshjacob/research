extern int* abstract_vectorAdd(int* A,int* B,int* C,int TOTAL_SIZE);
